import React from 'react'

// View component is responsible for rendering a single row in the Pokemon table
function View(props) {
  // Destructuring id and name from the passed "p" (Pokemon object) prop
  let { id, name } = props.p;

  return (
    <tr>
      {/* Displaying the Pokemon's ID in the first cell */}
      <td>{id}</td>
      
      {/* Displaying the Pokemon's name in the second cell */}
      <td>{name}</td>
    </tr>
  )
}

export default View; // Exporting the View component for use in other parts of the application
