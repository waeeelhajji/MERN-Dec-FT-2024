import React from 'react'

// FilterP component allows the user to filter the Pokemon list by type
function FilterP({ setSelectedType }) {
  return (
    <div>
      {/* Buttons to set the selected type for filtering */}
      {/* Each button updates the selected type using the setSelectedType function passed as a prop */}
      <button onClick={() => setSelectedType("all")}>All</button> {/* Shows all Pokemon */}
      <button onClick={() => setSelectedType("poison")}>Poison</button> {/* Filters by "poison" type */}
      <button onClick={() => setSelectedType("grass")}>Grass</button> {/* Filters by "grass" type */}
      <button onClick={() => setSelectedType("fire")}>Fire</button> {/* Filters by "fire" type */}
      <button onClick={() => setSelectedType("water")}>Water</button> {/* Filters by "water" type */}
      <button onClick={() => setSelectedType("bug")}>Bug</button> {/* Filters by "bug" type */}
      <button onClick={() => setSelectedType("flying")}>Flying</button> {/* Filters by "flying" type */}
      <button onClick={() => setSelectedType("electric")}>Electric</button> {/* Filters by "electric" type */}
    </div>
  )
}

export default FilterP; // Exporting the FilterP component for use in other parts of the application
