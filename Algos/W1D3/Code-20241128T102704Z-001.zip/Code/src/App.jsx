import { useState } from 'react' // Importing useState hook from React
import './App.css' // Importing CSS for styling
import View from './components/View'; // Importing a custom component for displaying Pokemon
import FilterP from './components/FilterP'; // Importing a custom component for filtering Pokemon by type

function App() {
  // State to store the list of Pokemon
  const [pokemon, setPokemon] = useState([
    // Initial array of Pokemon objects with their IDs, names, and types
    { "id": 1,   "name": "Bulbasaur",  "types": ["poison", "grass"] },
    { "id": 5,   "name": "Charmeleon", "types": ["fire"] },
    { "id": 9,   "name": "Blastoise",  "types": ["water"] },
    { "id": 12,  "name": "Butterfree", "types": ["bug", "flying"] },
    { "id": 16,  "name": "Pidgey",     "types": ["normal", "flying"] },
    { "id": 23,  "name": "Ekans",      "types": ["poison"] },
    { "id": 24,  "name": "Arbok",      "types": ["poison"] },
    { "id": 25,  "name": "Pikachu",    "types": ["electric"] },
    { "id": 35,  "name": "Clefairy",   "types": ["normal"] },
    { "id": 37,  "name": "Vulpix",     "types": ["fire"] },
    { "id": 52,  "name": "Meowth",     "types": ["normal"] },
    { "id": 63,  "name": "Abra",       "types": ["psychic"] },
    { "id": 67,  "name": "Machamp",    "types": ["fighting"] },
    { "id": 72,  "name": "Tentacool",  "types": ["water", "poison"] },
    { "id": 74,  "name": "Geodude",    "types": ["rock", "ground"] },
    { "id": 87,  "name": "Dewgong",    "types": ["water", "ice"] },
    { "id": 98,  "name": "Krabby",     "types": ["water"] },
    { "id": 115, "name": "Kangaskhan", "types": ["normal"] },
    { "id": 122, "name": "Mr. Mime",   "types": ["psychic"] },
    { "id": 133, "name": "Eevee",      "types": ["normal"] },
    { "id": 144, "name": "Articuno",   "types": ["ice", "flying"] },
    { "id": 145, "name": "Zapdos",     "types": ["electric", "flying"] },
    { "id": 146, "name": "Moltres",    "types": ["fire", "flying"] },
    { "id": 148, "name": "Dragonair",  "types": ["dragon"] }
  ])
  
  // State to store the currently selected Pokemon type for filtering
  const [selectedType, setSelectedType] = useState("all");

  // Filtering Pokemon based on the selected type
  const filteredPoke = pokemon.filter(p => {
    if (selectedType === "all") return pokemon; // If "all" is selected, show all Pokemon
    return p.types.includes(selectedType); // Otherwise, filter Pokemon by type
  });

  return (
    <>
      {/* Header of the application */}
      <h1>Pokemon List</h1>

      {/* Filter component to select the type of Pokemon to display */}
      <FilterP setSelectedType={setSelectedType}/>

      {/* Table to display the filtered Pokemon list */}
      <table>
        {/* Table header */}
        <tr>
          <th>ID</th>
          <th>Name</th>
        </tr>
        
        {/* Mapping over the filtered Pokemon list and rendering each as a row */}
        {filteredPoke.map(p => (
          <View p={p} /> // Using the View component to display individual Pokemon
        ))}
      </table>
    </>
  )
}

export default App; // Exporting the App component as the default export
